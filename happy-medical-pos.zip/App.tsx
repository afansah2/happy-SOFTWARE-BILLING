import React, { useState } from 'react';
import PosTab from './components/PosTab';
import MedicineTab from './components/MedicineTab';
import MonthlyBookTab from './components/MonthlyBookTab';
import { LayoutGrid, Pill, BookOpen, Stethoscope } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'pos' | 'medicines' | 'book'>('pos');

  return (
    <div className="h-full flex flex-col bg-gray-100 font-sans">
      {/* Header / Nav */}
      <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between shadow-sm z-10">
        <div className="flex items-center gap-3">
          <div className="bg-medical-500 p-2 rounded-lg">
            <Stethoscope className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 tracking-tight">Happy Medical</h1>
            <p className="text-xs text-gray-500 font-medium">Pharmacy POS System v1.0</p>
          </div>
        </div>

        <nav className="flex bg-gray-100 p-1 rounded-lg gap-1">
          <button
            onClick={() => setActiveTab('pos')}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
              activeTab === 'pos' 
                ? 'bg-white text-medical-700 shadow-sm' 
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-200'
            }`}
          >
            <LayoutGrid className="h-4 w-4" />
            Billing POS
          </button>
          <button
            onClick={() => setActiveTab('medicines')}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
              activeTab === 'medicines' 
                ? 'bg-white text-medical-700 shadow-sm' 
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-200'
            }`}
          >
            <Pill className="h-4 w-4" />
            Medicines
          </button>
          <button
            onClick={() => setActiveTab('book')}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
              activeTab === 'book' 
                ? 'bg-white text-medical-700 shadow-sm' 
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-200'
            }`}
          >
            <BookOpen className="h-4 w-4" />
            Monthly Book
          </button>
        </nav>
        
        <div className="text-sm text-gray-500 hidden md:block">
           {new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden relative">
        {activeTab === 'pos' && <PosTab />}
        {activeTab === 'medicines' && <MedicineTab />}
        {activeTab === 'book' && <MonthlyBookTab />}
      </main>
    </div>
  );
}

import { Medicine, Invoice, MonthlyBook, MedicineType } from '../types';

const MEDICINES_KEY = 'pharmacy_medicines';
const INVOICES_KEY = 'pharmacy_invoices';

// Initial Seed Data
const INITIAL_MEDICINES: Medicine[] = [
  { id: '1', name: 'Paracetamol 500mg', company: 'GSK', type: MedicineType.TABLET, price: 5.0, tax: 5, discount: 0, qty_in_stock: 1000, deleted: false, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: '2', name: 'Azithromycin 500mg', company: 'Pfizer', type: MedicineType.TABLET, price: 45.0, tax: 12, discount: 5, qty_in_stock: 200, deleted: false, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: '3', name: 'Cough Syrup', company: 'Dabur', type: MedicineType.SYRUP, price: 120.0, tax: 18, discount: 0, qty_in_stock: 50, deleted: false, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
  { id: '4', name: 'Insulin Glargine', company: 'Sanofi', type: MedicineType.INJECTION, price: 550.0, tax: 12, discount: 10, qty_in_stock: 20, deleted: false, created_at: new Date().toISOString(), updated_at: new Date().toISOString() },
];

// Helper to simulate async DB calls
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

class DatabaseService {
  constructor() {
    this.init();
  }

  private init() {
    if (!localStorage.getItem(MEDICINES_KEY)) {
      localStorage.setItem(MEDICINES_KEY, JSON.stringify(INITIAL_MEDICINES));
    }
    if (!localStorage.getItem(INVOICES_KEY)) {
      localStorage.setItem(INVOICES_KEY, JSON.stringify([]));
    }
  }

  async getMedicines(includeDeleted = false): Promise<Medicine[]> {
    await delay(100);
    const data = localStorage.getItem(MEDICINES_KEY);
    const meds: Medicine[] = data ? JSON.parse(data) : [];
    return includeDeleted ? meds : meds.filter(m => !m.deleted);
  }

  async saveMedicine(medicine: Medicine): Promise<void> {
    await delay(200);
    const data = localStorage.getItem(MEDICINES_KEY);
    let meds: Medicine[] = data ? JSON.parse(data) : [];
    
    const index = meds.findIndex(m => m.id === medicine.id);
    if (index >= 0) {
      meds[index] = { ...medicine, updated_at: new Date().toISOString() };
    } else {
      meds.push({ ...medicine, created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
    }
    
    localStorage.setItem(MEDICINES_KEY, JSON.stringify(meds));
  }

  async softDeleteMedicine(id: string): Promise<void> {
    await delay(100);
    const data = localStorage.getItem(MEDICINES_KEY);
    let meds: Medicine[] = data ? JSON.parse(data) : [];
    
    const index = meds.findIndex(m => m.id === id);
    if (index >= 0) {
      meds[index].deleted = true;
      meds[index].updated_at = new Date().toISOString();
      localStorage.setItem(MEDICINES_KEY, JSON.stringify(meds));
    }
  }

  async saveInvoice(invoice: Invoice): Promise<void> {
    await delay(200);
    const data = localStorage.getItem(INVOICES_KEY);
    let invoices: Invoice[] = data ? JSON.parse(data) : [];
    invoices.push(invoice);
    localStorage.setItem(INVOICES_KEY, JSON.stringify(invoices));

    // Decrease stock
    const medData = localStorage.getItem(MEDICINES_KEY);
    let meds: Medicine[] = medData ? JSON.parse(medData) : [];
    
    invoice.items.forEach(item => {
      const mIndex = meds.findIndex(m => m.id === item.id);
      if (mIndex >= 0) {
        meds[mIndex].qty_in_stock = Math.max(0, meds[mIndex].qty_in_stock - item.qty);
      }
    });
    localStorage.setItem(MEDICINES_KEY, JSON.stringify(meds));
  }

  async getInvoices(): Promise<Invoice[]> {
    await delay(100);
    const data = localStorage.getItem(INVOICES_KEY);
    return data ? JSON.parse(data) : [];
  }

  async getInvoicesByMonth(monthKey: string): Promise<Invoice[]> {
    await delay(100);
    const data = localStorage.getItem(INVOICES_KEY);
    const invoices: Invoice[] = data ? JSON.parse(data) : [];
    return invoices.filter(inv => inv.month_key === monthKey);
  }

  getNextInvoiceNumber(): string {
    const data = localStorage.getItem(INVOICES_KEY);
    const invoices: Invoice[] = data ? JSON.parse(data) : [];
    const count = invoices.length + 1;
    return `INV-${new Date().getFullYear()}-${String(count).padStart(5, '0')}`;
  }
}

export const db = new DatabaseService();

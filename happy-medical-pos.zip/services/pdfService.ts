import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Invoice } from '../types';
import { format } from 'date-fns';

export const generateInvoicePDF = (invoice: Invoice): jsPDF => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: [80, 200] // Thermal paper width approximation for digital viewing
  });

  doc.setFontSize(10);
  doc.text("HAPPY MEDICAL STORE", 40, 10, { align: 'center' });
  doc.setFontSize(8);
  doc.text("123 Pharmacy Street, Health City", 40, 14, { align: 'center' });
  doc.text("Phone: +1 234 567 890", 40, 18, { align: 'center' });

  doc.line(5, 22, 75, 22);

  doc.setFontSize(8);
  doc.text(`Invoice: ${invoice.id}`, 5, 26);
  doc.text(`Date: ${format(new Date(invoice.date), 'yyyy-MM-dd HH:mm')}`, 5, 30);
  if (invoice.customer_name) {
    doc.text(`Customer: ${invoice.customer_name}`, 5, 34);
  }

  const tableBody = invoice.items.map(item => [
    item.name.substring(0, 15),
    item.qty.toString(),
    item.price.toFixed(2),
    item.finalAmount.toFixed(2)
  ]);

  autoTable(doc, {
    startY: invoice.customer_name ? 38 : 34,
    head: [['Item', 'Qty', 'Price', 'Amt']],
    body: tableBody,
    theme: 'plain',
    styles: { fontSize: 7, cellPadding: 1 },
    headStyles: { fillColor: [220, 220, 220], textColor: 0, fontStyle: 'bold' },
    margin: { left: 2, right: 2 },
    tableWidth: 'auto'
  });

  const finalY = (doc as any).lastAutoTable.finalY + 4;

  doc.setFontSize(8);
  doc.text(`Subtotal:`, 45, finalY, { align: 'right' });
  doc.text(`${invoice.subtotal.toFixed(2)}`, 75, finalY, { align: 'right' });

  doc.text(`Discount:`, 45, finalY + 4, { align: 'right' });
  doc.text(`${invoice.discount_total.toFixed(2)}`, 75, finalY + 4, { align: 'right' });

  doc.text(`Tax:`, 45, finalY + 8, { align: 'right' });
  doc.text(`${invoice.tax_total.toFixed(2)}`, 75, finalY + 8, { align: 'right' });

  doc.line(5, finalY + 12, 75, finalY + 12);
  
  doc.setFontSize(10);
  doc.setFont("helvetica", "bold");
  doc.text(`Total:`, 45, finalY + 17, { align: 'right' });
  doc.text(`${invoice.grand_total.toFixed(2)}`, 75, finalY + 17, { align: 'right' });

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text("Thank you for shopping!", 40, finalY + 25, { align: 'center' });

  return doc;
};

export enum MedicineType {
  TABLET = 'Tablet',
  SYRUP = 'Syrup',
  INJECTION = 'Injection',
  CAPSULE = 'Capsule',
  OINTMENT = 'Ointment',
  OTHER = 'Other'
}

export interface Medicine {
  id: string;
  name: string;
  company: string;
  type: MedicineType;
  price: number;
  tax: number; // Percentage
  discount: number; // Percentage
  qty_in_stock: number;
  deleted: boolean;
  created_at: string;
  updated_at: string;
}

export interface CartItem extends Medicine {
  qty: number;
  totalPrice: number; // (Price * Qty)
  totalTax: number; // ((Price * Qty) * Tax / 100)
  totalDiscount: number; // ((Price * Qty) * Discount / 100)
  finalAmount: number; // totalPrice + totalTax - totalDiscount
}

export interface Invoice {
  id: string; // Auto-generated Invoice Number
  date: string; // ISO String
  customer_name?: string;
  items: CartItem[];
  subtotal: number;
  discount_total: number;
  tax_total: number;
  grand_total: number;
  month_key: string; // Helper for Monthly Book (e.g., "2023-10")
}

export interface MonthlyBook {
  id: string;
  month_key: string; // YYYY-MM
  name: string; // "October 2023 Book"
  invoice_ids: string[];
  created_at: string;
}

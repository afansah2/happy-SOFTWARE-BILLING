import React, { useState, useEffect, useRef } from 'react';
import { Search, Plus, Trash2, Printer, ShoppingCart, X } from 'lucide-react';
import { Medicine, CartItem, Invoice } from '../types';
import { db } from '../services/db';
import { ReceiptPrint } from './ReceiptPrint';
import { generateInvoicePDF } from '../services/pdfService';

export default function PosTab() {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null);
  const [addQty, setAddQty] = useState<number>(1);
  const [customerName, setCustomerName] = useState('');
  const [lastPrintedInvoice, setLastPrintedInvoice] = useState<Invoice | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const receiptRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadMedicines();
  }, []);

  const loadMedicines = async () => {
    const data = await db.getMedicines(false); // Only non-deleted
    setMedicines(data);
  };

  // Filter medicines for search
  const filteredMedicines = medicines.filter(m => 
    m.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const openAddModal = (med: Medicine) => {
    setSelectedMedicine(med);
    setAddQty(1);
  };

  const addToCart = () => {
    if (!selectedMedicine) return;

    const existingItemIndex = cart.findIndex(item => item.id === selectedMedicine.id);
    const basePrice = selectedMedicine.price * addQty;
    const taxAmt = (basePrice * selectedMedicine.tax) / 100;
    const discountAmt = (basePrice * selectedMedicine.discount) / 100;
    const final = basePrice + taxAmt - discountAmt;

    const newItem: CartItem = {
      ...selectedMedicine,
      qty: addQty,
      totalPrice: basePrice,
      totalTax: taxAmt,
      totalDiscount: discountAmt,
      finalAmount: final
    };

    if (existingItemIndex >= 0) {
      // Update existing
      const updatedCart = [...cart];
      const existing = updatedCart[existingItemIndex];
      const newQty = existing.qty + addQty;
      const newBase = selectedMedicine.price * newQty;
      const newTax = (newBase * selectedMedicine.tax) / 100;
      const newDisc = (newBase * selectedMedicine.discount) / 100;
      
      updatedCart[existingItemIndex] = {
        ...existing,
        qty: newQty,
        totalPrice: newBase,
        totalTax: newTax,
        totalDiscount: newDisc,
        finalAmount: newBase + newTax - newDisc
      };
      setCart(updatedCart);
    } else {
      setCart([...cart, newItem]);
    }

    setSelectedMedicine(null);
    setSearchQuery('');
  };

  const removeFromCart = (index: number) => {
    const newCart = [...cart];
    newCart.splice(index, 1);
    setCart(newCart);
  };

  const totals = cart.reduce((acc, item) => ({
    subtotal: acc.subtotal + item.totalPrice,
    tax: acc.tax + item.totalTax,
    discount: acc.discount + item.totalDiscount,
    total: acc.total + item.finalAmount
  }), { subtotal: 0, tax: 0, discount: 0, total: 0 });

  const handlePrint = async () => {
    if (cart.length === 0) return;
    setIsLoading(true);

    const now = new Date();
    const invoice: Invoice = {
      id: db.getNextInvoiceNumber(),
      date: now.toISOString(),
      customer_name: customerName,
      items: cart,
      subtotal: totals.subtotal,
      tax_total: totals.tax,
      discount_total: totals.discount,
      grand_total: totals.total,
      month_key: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
    };

    await db.saveInvoice(invoice);
    setLastPrintedInvoice(invoice);

    // Simulate creating/saving the PDF for the Monthly Book "file system"
    // In a real app with FS access, we'd write the file. 
    // Here, db.saveInvoice effectively persists the data which we can regenerate as PDF on demand.
    // We can also console.log "Saved to Google Sheet" behavior here.
    console.log("Simulating Google Sheet Entry:", {
      invoice_id: invoice.id,
      date: invoice.date,
      customer: invoice.customer_name,
      total: invoice.grand_total,
      items_json: JSON.stringify(invoice.items)
    });

    // Wait for state update to render print component
    setTimeout(() => {
      window.print();
      setCart([]);
      setCustomerName('');
      loadMedicines(); // Reload stock
      setIsLoading(false);
    }, 500);
  };

  return (
    <div className="flex h-full gap-4 p-4 bg-gray-100">
      {/* Left: Search & Product List */}
      <div className="w-2/3 flex flex-col gap-4">
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search medicines by name..."
              className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-medical-500 transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              autoFocus
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredMedicines.map((med) => (
              <button
                key={med.id}
                onClick={() => openAddModal(med)}
                className="flex flex-col items-start p-4 border border-gray-100 rounded-lg hover:border-medical-500 hover:bg-medical-50 transition-all text-left group"
              >
                <div className="flex justify-between w-full mb-1">
                  <span className="font-semibold text-gray-800 truncate w-full pr-2">{med.name}</span>
                </div>
                <div className="text-xs text-gray-500 mb-2">{med.company} • {med.type}</div>
                <div className="flex justify-between w-full items-center mt-auto">
                  <span className="font-mono font-bold text-medical-700">${med.price.toFixed(2)}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${med.qty_in_stock > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    Stock: {med.qty_in_stock}
                  </span>
                </div>
              </button>
            ))}
            {filteredMedicines.length === 0 && (
              <div className="col-span-full text-center py-10 text-gray-400">
                No medicines found.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Right: Cart */}
      <div className="w-1/3 bg-white rounded-xl shadow-lg border border-gray-200 flex flex-col h-full">
        <div className="p-4 border-b border-gray-100 bg-gray-50 rounded-t-xl">
          <h2 className="font-bold text-lg flex items-center gap-2 text-gray-800">
            <ShoppingCart className="h-5 w-5 text-medical-600" />
            Current Bill
          </h2>
          <input
            type="text"
            placeholder="Customer Name (Optional)"
            className="w-full mt-3 px-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:border-medical-500"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
          />
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-gray-300">
              <ShoppingCart className="h-12 w-12 mb-2 opacity-20" />
              <p>Cart is empty</p>
            </div>
          ) : (
            cart.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-100">
                <div className="flex-1 min-w-0 mr-2">
                  <div className="font-medium text-gray-800 truncate">{item.name}</div>
                  <div className="text-xs text-gray-500">
                    {item.qty} x {item.price.toFixed(2)} 
                    {item.discount > 0 && <span className="text-green-600 ml-1">(-{item.discount}%)</span>}
                    {item.tax > 0 && <span className="text-orange-600 ml-1">(+{item.tax}% Tax)</span>}
                  </div>
                </div>
                <div className="text-right mr-3">
                  <div className="font-bold text-gray-800">${item.finalAmount.toFixed(2)}</div>
                </div>
                <button 
                  onClick={() => removeFromCart(idx)}
                  className="text-red-400 hover:text-red-600 p-1 rounded-md hover:bg-red-50"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))
          )}
        </div>

        <div className="p-4 border-t border-gray-100 bg-gray-50 rounded-b-xl">
          <div className="space-y-2 text-sm text-gray-600 mb-4">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>{totals.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-green-600">
              <span>Discount</span>
              <span>-{totals.discount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-orange-600">
              <span>Tax</span>
              <span>+{totals.tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-xl font-bold text-gray-900 pt-2 border-t border-gray-200">
              <span>Total</span>
              <span>${totals.total.toFixed(2)}</span>
            </div>
          </div>
          
          <button
            onClick={handlePrint}
            disabled={cart.length === 0 || isLoading}
            className="w-full py-3 bg-medical-600 hover:bg-medical-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-bold rounded-lg shadow-md transition-all flex items-center justify-center gap-2"
          >
            <Printer className="h-5 w-5" />
            {isLoading ? 'Processing...' : 'Print Receipt & Save'}
          </button>
        </div>
      </div>

      {/* Add Qty Modal */}
      {selectedMedicine && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-2xl transform transition-all scale-100">
            <h3 className="text-xl font-bold mb-1">{selectedMedicine.name}</h3>
            <p className="text-gray-500 text-sm mb-6">{selectedMedicine.company} • {selectedMedicine.type}</p>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 p-3 rounded-lg">
                <span className="text-xs text-gray-500 block">Price</span>
                <span className="font-mono font-bold">${selectedMedicine.price.toFixed(2)}</span>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <span className="text-xs text-gray-500 block">Available</span>
                <span className="font-mono font-bold">{selectedMedicine.qty_in_stock}</span>
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Quantity</label>
              <input
                type="number"
                min="1"
                max={selectedMedicine.qty_in_stock}
                className="w-full p-3 border border-gray-300 rounded-lg text-lg font-bold text-center focus:ring-2 focus:ring-medical-500 outline-none"
                value={addQty}
                onChange={(e) => setAddQty(parseInt(e.target.value) || 0)}
                autoFocus
                onKeyDown={(e) => e.key === 'Enter' && addToCart()}
              />
            </div>

            <div className="flex gap-3">
              <button 
                onClick={() => setSelectedMedicine(null)}
                className="flex-1 py-3 text-gray-600 font-semibold bg-gray-100 rounded-lg hover:bg-gray-200"
              >
                Cancel
              </button>
              <button 
                onClick={addToCart}
                disabled={addQty < 1 || addQty > selectedMedicine.qty_in_stock}
                className="flex-1 py-3 bg-medical-600 text-white font-bold rounded-lg hover:bg-medical-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                Add to Bill
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Hidden Print Component */}
      <ReceiptPrint ref={receiptRef} invoice={lastPrintedInvoice} />
    </div>
  );
}

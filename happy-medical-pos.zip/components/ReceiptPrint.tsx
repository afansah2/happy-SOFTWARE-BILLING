import React, { forwardRef } from 'react';
import { Invoice } from '../types';
import { format } from 'date-fns';

interface ReceiptPrintProps {
  invoice: Invoice | null;
}

export const ReceiptPrint = forwardRef<HTMLDivElement, ReceiptPrintProps>(({ invoice }, ref) => {
  if (!invoice) return null;

  return (
    <div ref={ref} id="receipt-print-area" className="hidden print:block font-mono text-[12px] leading-tight w-[80mm]">
      <div className="text-center mb-4">
        <h1 className="text-lg font-bold">HAPPY MEDICAL STORE</h1>
        <p>123 Pharmacy Street, Health City</p>
        <p>Phone: +1 234 567 890</p>
      </div>

      <div className="mb-2 border-b border-black pb-2 border-dashed">
        <p>Invoice: {invoice.id}</p>
        <p>Date: {format(new Date(invoice.date), 'yyyy-MM-dd HH:mm')}</p>
        {invoice.customer_name && <p>Cust: {invoice.customer_name}</p>}
      </div>

      <table className="w-full mb-2">
        <thead>
          <tr className="border-b border-black border-dashed">
            <th className="text-left w-[40%]">Item</th>
            <th className="text-center w-[15%]">Qty</th>
            <th className="text-right w-[20%]">Price</th>
            <th className="text-right w-[25%]">Amt</th>
          </tr>
        </thead>
        <tbody>
          {invoice.items.map((item, i) => (
            <tr key={i}>
              <td className="text-left truncate pr-1">{item.name}</td>
              <td className="text-center">{item.qty}</td>
              <td className="text-right">{item.price.toFixed(2)}</td>
              <td className="text-right">{item.finalAmount.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="border-t border-black border-dashed pt-2 space-y-1">
        <div className="flex justify-between">
          <span>Subtotal:</span>
          <span>{invoice.subtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span>Discount:</span>
          <span>{invoice.discount_total.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span>Tax:</span>
          <span>{invoice.tax_total.toFixed(2)}</span>
        </div>
        <div className="flex justify-between font-bold text-base mt-2 border-t border-black border-double pt-1">
          <span>Total:</span>
          <span>{invoice.grand_total.toFixed(2)}</span>
        </div>
      </div>

      <div className="text-center mt-6 border-t border-black pb-4 pt-2">
        <p>Thank you for shopping!</p>
        <p>Come again.</p>
      </div>
    </div>
  );
});

ReceiptPrint.displayName = 'ReceiptPrint';

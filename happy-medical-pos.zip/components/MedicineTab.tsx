import React, { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, Search, RefreshCw, Archive } from 'lucide-react';
import { Medicine, MedicineType } from '../types';
import { db } from '../services/db';

export default function MedicineTab() {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showDeleted, setShowDeleted] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const emptyForm = {
    name: '',
    company: '',
    type: MedicineType.TABLET,
    price: 0,
    tax: 0,
    discount: 0,
    qty_in_stock: 0,
  };

  const [formData, setFormData] = useState(emptyForm);

  useEffect(() => {
    loadData();
  }, [showDeleted]);

  const loadData = async () => {
    const data = await db.getMedicines(showDeleted);
    setMedicines(data);
  };

  const handleSave = async () => {
    if (!formData.name || formData.price < 0) return;

    const newMed: Medicine = {
      id: editingId || crypto.randomUUID(),
      ...formData,
      deleted: false,
      created_at: new Date().toISOString(), // simplistic, in real app preserve original created_at if edit
      updated_at: new Date().toISOString()
    };

    // If editing, we need to preserve original fields not in form
    if (editingId) {
      const original = medicines.find(m => m.id === editingId);
      if (original) {
        newMed.created_at = original.created_at;
        newMed.deleted = original.deleted;
      }
    }

    await db.saveMedicine(newMed);
    setShowModal(false);
    setEditingId(null);
    setFormData(emptyForm);
    loadData();
  };

  const handleEdit = (med: Medicine) => {
    setEditingId(med.id);
    setFormData({
      name: med.name,
      company: med.company,
      type: med.type,
      price: med.price,
      tax: med.tax,
      discount: med.discount,
      qty_in_stock: med.qty_in_stock,
    });
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to move this medicine to trash?')) {
      await db.softDeleteMedicine(id);
      loadData();
    }
  };

  const filtered = medicines.filter(m => 
    m.name.toLowerCase().includes(search.toLowerCase()) ||
    m.company.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="h-full p-6 bg-gray-50 flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Medicine Inventory</h2>
        <div className="flex gap-3">
           <button
            onClick={() => setShowDeleted(!showDeleted)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg border font-medium transition-colors ${showDeleted ? 'bg-gray-800 text-white border-gray-800' : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'}`}
          >
            <Archive className="h-4 w-4" />
            {showDeleted ? 'Hide Trash' : 'Show Trash'}
          </button>
          <button
            onClick={() => { setEditingId(null); setFormData(emptyForm); setShowModal(true); }}
            className="flex items-center gap-2 px-4 py-2 bg-medical-600 text-white rounded-lg hover:bg-medical-700 font-medium shadow-sm"
          >
            <Plus className="h-4 w-4" />
            Add Medicine
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 flex-1 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-gray-100 bg-gray-50/50">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search by name or company..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-500 focus:border-medical-500 outline-none"
            />
          </div>
        </div>

        <div className="overflow-auto flex-1">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-gray-500 uppercase bg-gray-50 border-b sticky top-0">
              <tr>
                <th className="px-6 py-3">Name</th>
                <th className="px-6 py-3">Company</th>
                <th className="px-6 py-3">Type</th>
                <th className="px-6 py-3 text-right">Price</th>
                <th className="px-6 py-3 text-right">Tax %</th>
                <th className="px-6 py-3 text-right">Stock</th>
                <th className="px-6 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map((med) => (
                <tr key={med.id} className={`hover:bg-gray-50 ${med.deleted ? 'bg-red-50 opacity-75' : ''}`}>
                  <td className="px-6 py-4 font-medium text-gray-900">
                    {med.name}
                    {med.deleted && <span className="ml-2 text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full">Deleted</span>}
                  </td>
                  <td className="px-6 py-4 text-gray-500">{med.company}</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs">{med.type}</span>
                  </td>
                  <td className="px-6 py-4 text-right font-mono">${med.price.toFixed(2)}</td>
                  <td className="px-6 py-4 text-right">{med.tax}%</td>
                  <td className="px-6 py-4 text-right font-bold">{med.qty_in_stock}</td>
                  <td className="px-6 py-4 flex justify-center gap-2">
                    <button onClick={() => handleEdit(med)} className="p-1 text-blue-600 hover:bg-blue-50 rounded">
                      <Pencil className="h-4 w-4" />
                    </button>
                    {!med.deleted && (
                      <button onClick={() => handleDelete(med.id)} className="p-1 text-red-600 hover:bg-red-50 rounded">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-6 py-10 text-center text-gray-400">
                    No medicines found matching your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit/Add Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl p-6 max-h-[90vh] overflow-y-auto">
            <h3 className="text-xl font-bold text-gray-800 mb-6">{editingId ? 'Edit Medicine' : 'New Medicine'}</h3>
            
            <div className="grid grid-cols-2 gap-6">
              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Medicine Name</label>
                <input 
                  type="text" 
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-medical-500 outline-none"
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Company</label>
                <input 
                  type="text" 
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-medical-500 outline-none"
                  value={formData.company}
                  onChange={e => setFormData({...formData, company: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                <select 
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-medical-500 outline-none bg-white"
                  value={formData.type}
                  onChange={e => setFormData({...formData, type: e.target.value as MedicineType})}
                >
                  {Object.values(MedicineType).map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Price ($)</label>
                <input 
                  type="number" 
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-medical-500 outline-none"
                  value={formData.price}
                  onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Stock Qty</label>
                <input 
                  type="number" 
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-medical-500 outline-none"
                  value={formData.qty_in_stock}
                  onChange={e => setFormData({...formData, qty_in_stock: parseInt(e.target.value)})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tax (%)</label>
                <input 
                  type="number" 
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-medical-500 outline-none"
                  value={formData.tax}
                  onChange={e => setFormData({...formData, tax: parseFloat(e.target.value)})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Discount (%)</label>
                <input 
                  type="number" 
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-medical-500 outline-none"
                  value={formData.discount}
                  onChange={e => setFormData({...formData, discount: parseFloat(e.target.value)})}
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-8 pt-4 border-t">
              <button 
                onClick={() => setShowModal(false)}
                className="px-4 py-2 text-gray-600 font-medium hover:bg-gray-100 rounded-lg"
              >
                Cancel
              </button>
              <button 
                onClick={handleSave}
                className="px-6 py-2 bg-medical-600 text-white font-medium rounded-lg hover:bg-medical-700 shadow-md"
              >
                Save Medicine
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useEffect, useState } from 'react';
import { Folder, FileText, Download, ChevronRight } from 'lucide-react';
import { Invoice } from '../types';
import { db } from '../services/db';
import { generateInvoicePDF } from '../services/pdfService';
import { format } from 'date-fns';

export default function MonthlyBookTab() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [selectedMonth, setSelectedMonth] = useState<string | null>(null);
  
  useEffect(() => {
    loadInvoices();
  }, []);

  const loadInvoices = async () => {
    const data = await db.getInvoices();
    setInvoices(data);
    
    // Auto-select current month if available
    const currentMonthKey = `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}`;
    if (data.some(inv => inv.month_key === currentMonthKey) && !selectedMonth) {
      setSelectedMonth(currentMonthKey);
    }
  };

  // Group keys
  const monthKeys = Array.from(new Set(invoices.map(i => i.month_key))).sort().reverse();
  
  const filteredInvoices = selectedMonth 
    ? invoices.filter(i => i.month_key === selectedMonth).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    : [];

  const handleDownloadPDF = (invoice: Invoice) => {
    const doc = generateInvoicePDF(invoice);
    doc.save(`Invoice-${invoice.id}.pdf`);
  };

  const handleDownloadMonthBook = () => {
    if (!selectedMonth || filteredInvoices.length === 0) return;
    
    // In a real browser app without a backend, zipping PDFs is heavy.
    // We will trigger individual downloads for simplicity or create a merged PDF.
    // For this demo, let's create a Merged PDF Report which acts as the "Book".
    
    import('jspdf').then(({ default: jsPDF }) => {
      import('jspdf-autotable').then(({ default: autoTable }) => {
        const doc = new jsPDF();
        doc.setFontSize(18);
        doc.text(`Monthly Book: ${selectedMonth}`, 14, 20);
        
        const rows = filteredInvoices.map(inv => [
          inv.id,
          format(new Date(inv.date), 'yyyy-MM-dd HH:mm'),
          inv.customer_name || '-',
          inv.items.length.toString(),
          inv.grand_total.toFixed(2)
        ]);

        (doc as any).autoTable({
          startY: 30,
          head: [['Invoice #', 'Date', 'Customer', 'Items', 'Total']],
          body: rows,
        });

        doc.save(`${selectedMonth}-Book-Report.pdf`);
      });
    });
  };

  return (
    <div className="h-full flex bg-gray-100 p-6 gap-6">
      {/* Sidebar: Months */}
      <div className="w-64 bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-100">
          <h3 className="font-bold text-gray-700 flex items-center gap-2">
            <Folder className="h-5 w-5 text-medical-600" />
            Books Collection
          </h3>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {monthKeys.length === 0 ? (
            <div className="text-sm text-gray-400 p-4 text-center">No records yet.</div>
          ) : (
            monthKeys.map(key => (
              <button
                key={key}
                onClick={() => setSelectedMonth(key)}
                className={`w-full flex items-center justify-between p-3 rounded-lg mb-1 transition-colors text-sm font-medium ${
                  selectedMonth === key 
                    ? 'bg-medical-50 text-medical-700 border border-medical-100' 
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <span className="flex items-center gap-2">
                   <Folder className={`h-4 w-4 ${selectedMonth === key ? 'fill-medical-200' : ''}`} />
                   {key} Book
                </span>
                {selectedMonth === key && <ChevronRight className="h-4 w-4" />}
              </button>
            ))
          )}
        </div>
      </div>

      {/* Main: Invoices in selected Book */}
      <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col">
        {selectedMonth ? (
          <>
            <div className="p-6 border-b border-gray-100 flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
                  {selectedMonth} Book
                  <span className="text-sm font-normal text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">
                    {filteredInvoices.length} Invoices
                  </span>
                </h2>
                <p className="text-sm text-gray-500 mt-1">Auto-archived daily receipts</p>
              </div>
              <button 
                onClick={handleDownloadMonthBook}
                className="flex items-center gap-2 px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-900 shadow-sm transition-all"
              >
                <Download className="h-4 w-4" />
                Download Book Summary
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {filteredInvoices.map(inv => (
                  <div key={inv.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow bg-gray-50/50 group">
                    <div className="flex justify-between items-start mb-2">
                      <div className="p-2 bg-white rounded-lg border border-gray-100">
                        <FileText className="h-6 w-6 text-medical-500" />
                      </div>
                      <button 
                        onClick={() => handleDownloadPDF(inv)}
                        className="text-gray-400 hover:text-medical-600 transition-colors"
                        title="Download PDF"
                      >
                        <Download className="h-5 w-5" />
                      </button>
                    </div>
                    <div className="font-mono font-bold text-gray-800 mb-1">{inv.id}</div>
                    <div className="text-xs text-gray-500 mb-3">{format(new Date(inv.date), 'MMM d, yyyy HH:mm')}</div>
                    <div className="flex justify-between items-center pt-3 border-t border-gray-200">
                      <span className="text-xs text-gray-500">{inv.items.length} Items</span>
                      <span className="font-bold text-gray-900">${inv.grand_total.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-gray-300">
            <Folder className="h-16 w-16 mb-4 opacity-20" />
            <p className="text-lg">Select a Monthly Book to view archives</p>
          </div>
        )}
      </div>
    </div>
  );
}
